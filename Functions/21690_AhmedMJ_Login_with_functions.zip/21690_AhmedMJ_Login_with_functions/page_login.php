<?php

echo "<h1 align='center'>---Main Form Page--</h1>";


include("login.php");


Login("POST","page3_datapost.php");
Register("POST","page3_datapost.php");









?>